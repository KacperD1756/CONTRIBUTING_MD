"""All configurations."""
PREFIX = "!"
BOT_NAME = ""
