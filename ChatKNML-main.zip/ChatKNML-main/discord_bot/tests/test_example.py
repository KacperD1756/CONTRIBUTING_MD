"""Example test module."""


def test_example():
    """Example test function."""
    assert True
