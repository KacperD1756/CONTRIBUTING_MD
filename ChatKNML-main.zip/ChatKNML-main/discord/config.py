PREFIX = "!"
BOT_NAME = ""
