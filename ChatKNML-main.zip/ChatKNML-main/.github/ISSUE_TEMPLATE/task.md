---
name: Task
about: Wyznaczanie zadań
title: ''
labels: ''

---

## Jaki jest cel tego tego zadania

Opisać konkretnie czemu to zadanie ma służyć.
np. Wdrożenie nowej funkcjonalności, lewitowanie kota, naprawa buga

## Jak wygląda rozwiązanie?

Zaproponuj jakbyś wykonał task. Zrób listę co w ramach taska trzeba zrobić.

np. Dodać świecące diody led, żeby bot wyglądał jak potwór z bagien

## TODO

- Kupić ledy
- Przymocować do monitora
- Zrobić dokumentację
- Napisać testy

## Powiązane taski/bugi

Czy task jest blokowowany przez jakiś inny lub jest powiązany z innym.

## Dodatkowe linki

Linki do źródeł lub dokumentacji!
